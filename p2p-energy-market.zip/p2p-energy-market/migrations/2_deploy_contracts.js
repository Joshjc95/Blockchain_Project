var EnergyMarket = artifacts.require("EnergyMarket");

module.exports = function(deployer) {
  deployer.deploy(EnergyMarket);
};
